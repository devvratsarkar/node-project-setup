import mongoose from "mongoose";
import { DB_NAME } from "../constants.js";

const connectionDB = async () => {
    try {
        const connectionInstance = await mongoose.connect(`${process.env.DB_URL}/${DB_NAME}`)
        console.log(`\nMONGODB Connected !! DB HOME: ${connectionInstance.connection.host} \n`);
    } catch (error) {
        console.log('MONGODB Connection FAILED', error);
        process.exit(1);
    }
}

export default connectionDB